/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ReportField {
  id: string;
  label: string;
  value: string | number;
  type: 'text' | 'select' | 'number';
  editable?: boolean;
  unit?: string;
}

export interface Equipment {
  id: string;
  name: string;
  attributes: Record<string, string | number>;
  status: 'selected' | 'available' | 'excluded';
  exclusionReason?: string;
}

export interface RunStatus {
  runId: string;
  overallStatus: 'idle' | 'processing' | 'waiting_manual_input' | 'completed' | 'failed';
  currentStage: string;
  uploadedFile: string;
}

export interface StructuredReport {
  id: string;
  title: string;
  fields: ReportField[];
}
