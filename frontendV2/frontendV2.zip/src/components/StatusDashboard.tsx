/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RunStatus } from '../types';
import { Fingerprint, Activity, Clock, FileCheck } from 'lucide-react';

export const StatusDashboard: React.FC<{ status: RunStatus }> = ({ status }) => {
  const getStatusColor = (s: string) => {
    switch (s) {
      case 'completed': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'waiting_manual_input': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'processing': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const items = [
    { label: '运行 ID', value: status.runId, icon: Fingerprint },
    { label: '整体状态', value: status.overallStatus, icon: Activity, isStatus: true },
    { label: '当前阶段', value: status.currentStage, icon: Clock },
    { label: '原始文件', value: status.uploadedFile, icon: FileCheck },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
      {items.map((item, idx) => (
        <div key={idx} className="glass-panel p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover:text-indigo-600 transition-colors">
            <item.icon size={20} />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-0.5">{item.label}</p>
            {item.isStatus ? (
              <span className={`status-badge border ${getStatusColor(item.value)}`}>
                {item.value.replace(/_/g, ' ')}
              </span>
            ) : (
              <p className="text-sm font-semibold text-slate-700 truncate">{item.value}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};
