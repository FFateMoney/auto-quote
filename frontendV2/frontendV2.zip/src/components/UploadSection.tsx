/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Upload, FileText, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

interface UploadSectionProps {
  onStart: (file: File | null) => void;
}

export const UploadSection: React.FC<UploadSectionProps> = ({ onStart }) => {
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto pt-16"
    >
      <div className="glass-panel p-8 text-center">
        <div className="mb-6">
          <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-indigo-100">
            <Upload size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">上传原始文档</h2>
          <p className="text-slate-500 mt-2">支持 .xlsx, .csv 格式的实验要求说明文本</p>
        </div>

        <div className="relative group cursor-pointer">
          <input
            type="file"
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
          <div className={`border-2 border-dashed rounded-xl p-10 transition-colors ${selectedFile ? 'border-indigo-400 bg-indigo-50/30' : 'border-slate-200 group-hover:border-indigo-300 bg-slate-50/50'}`}>
            {selectedFile ? (
              <div className="flex items-center justify-center gap-3">
                <FileText className="text-indigo-600" />
                <span className="font-medium text-slate-700">{selectedFile.name}</span>
                <CheckCircle2 className="text-emerald-500" size={18} />
              </div>
            ) : (
              <div className="text-slate-400">
                拖拽文件到此处 或 <span className="text-indigo-600 font-medium">点击选择</span>
              </div>
            )}
          </div>
        </div>

        <button 
          onClick={() => onStart(selectedFile)}
          disabled={!selectedFile}
          className="btn-primary w-full mt-8 disabled:opacity-50 disabled:shadow-none"
        >
          开始智能填表
        </button>
        
        <p className="mt-6 text-xs text-slate-400 flex items-center justify-center gap-2">
          当前 API 节点: <code className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">/api/v2/extract</code>
        </p>
      </div>
    </motion.div>
  );
};
