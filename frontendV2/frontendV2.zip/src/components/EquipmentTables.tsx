/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Equipment } from '../types';
import { ShieldCheck, Info, XCircle, RefreshCw } from 'lucide-react';

export const EquipmentTables: React.FC<{ equipments: Equipment[] }> = ({ equipments }) => {
  const matching = equipments.filter(e => e.status !== 'excluded');
  const excluded = equipments.filter(e => e.status === 'excluded');

  return (
    <div className="space-y-12">
      {/* Matching Table */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            匹配设备表
            <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full border border-indigo-100">
              {matching.length} 台符合
            </span>
          </h3>
          <p className="text-xs text-slate-400 italic">展示当前候选设备的非空属性，方便对照设备能力。</p>
        </div>
        
        <div className="glass-panel overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/80 border-bottom border-slate-200">
              <tr>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-400 uppercase tracking-widest">设备名称</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-400 uppercase tracking-widest">关键属性明细</th>
                <th className="px-6 py-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {matching.map((device) => (
                <tr key={device.id} className="group hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 align-top">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-800 tracking-tight">{device.name}</span>
                      {device.status === 'selected' && (
                        <span className="flex items-center gap-1 text-[9px] font-bold bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded uppercase border border-emerald-100">
                          <CheckCircleMini /> 当前选中
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm leading-relaxed">
                    <div className="flex flex-wrap gap-x-4 gap-y-2">
                      {Object.entries(device.attributes).map(([key, val]) => (
                        <div key={key} className="flex items-center gap-1.5">
                          <span className="text-slate-400 text-xs">{key}:</span>
                          <span className="text-slate-700 font-mono text-xs">{val}</span>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right align-top">
                    <button className="btn-secondary group-hover:bg-white text-xs py-1.5 px-3 flex items-center gap-2 ml-auto">
                      <RefreshCw size={12} className="text-indigo-500" />
                      选用并重新报价
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Exclusion Section */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            被筛选设备表
            {excluded.length > 0 && <span className="text-red-500"><XCircle size={18} /></span>}
          </h3>
          <p className="text-xs text-slate-400 italic">展示当前阶段基于限制条件的筛除结果。</p>
        </div>

        {excluded.length > 0 ? (
          <div className="grid gap-3">
            {excluded.map(device => (
              <div key={device.id} className="glass-panel p-4 border-l-4 border-l-red-400 flex items-start justify-between bg-red-50/5">
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-lg bg-red-50 border border-red-100 flex items-center justify-center text-red-500 shrink-0">
                    <Info size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 mb-1">{device.name}</h4>
                    <p className="text-sm text-red-600 font-medium">原因: {device.exclusionReason}</p>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
                      {Object.entries(device.attributes).map(([key, val]) => (
                        <span key={key} className="text-[10px] text-slate-400 uppercase tracking-tighter">
                          {key}: {val}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="border-2 border-dashed border-slate-100 rounded-2xl p-12 text-center text-slate-300 italic">
            当前阶段没有被筛除设备。
          </div>
        )}
      </section>
    </div>
  );
};

const CheckCircleMini = () => (
  <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.5 2.5L3.5 5.5L1.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
