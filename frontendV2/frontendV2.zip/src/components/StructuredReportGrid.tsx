/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { StructuredReport } from '../types';
import { Edit3, ChevronRight, Hash, Type, List } from 'lucide-react';
import { motion } from 'motion/react';

export const StructuredReportGrid: React.FC<{ report: StructuredReport }> = ({ report }) => {
  return (
    <div className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <ChevronRight className="text-indigo-400" />
            {report.title}
          </h3>
          <p className="text-xs text-slate-400 mt-1 font-mono">Row ID: {report.id}</p>
        </div>
        <div className="text-xs text-slate-500 max-w-md text-right leading-relaxed italic">
          最终报价的完整表格快照；指定字段可人工修正并重新报价。
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
        {report.fields.map((field, idx) => (
          <motion.div
            key={field.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.02 }}
            className={`glass-panel p-4 flex flex-col justify-between group relative overflow-hidden transition-all hover:ring-2 hover:ring-indigo-200 ${field.value === '-' ? 'bg-slate-50/50' : 'bg-white'}`}
          >
            {/* Type Indicator */}
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-20 transition-opacity">
              {field.type === 'number' ? <Hash size={14} /> : field.type === 'select' ? <List size={14} /> : <Type size={14} />}
            </div>

            <div>
              <p className="text-[11px] font-bold text-slate-400 leading-tight mb-2 min-h-8">
                {field.label}
              </p>
              <div className="flex items-baseline gap-1">
                <span className={`text-base font-semibold font-mono ${field.value === '-' ? 'text-slate-300' : 'text-indigo-900'}`}>
                  {field.value}
                </span>
                {field.unit && <span className="text-[10px] text-slate-400">{field.unit}</span>}
              </div>
            </div>

            {field.editable && (
              <button className="mt-3 flex items-center gap-1.5 text-[10px] font-bold text-indigo-500 hover:text-indigo-700 transition-colors uppercase tracking-widest bg-indigo-50/50 group-hover:bg-indigo-50 px-2 py-1 rounded border border-transparent hover:border-indigo-100 self-start">
                <Edit3 size={10} />
                编辑
              </button>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};
