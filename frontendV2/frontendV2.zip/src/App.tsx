/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UploadSection } from './components/UploadSection';
import { StatusDashboard } from './components/StatusDashboard';
import { StructuredReportGrid } from './components/StructuredReportGrid';
import { EquipmentTables } from './components/EquipmentTables';
import { 
  mockRunStatus, 
  mockReport, 
  mockEquipment 
} from './mockData';
import { Beaker, Settings, LayoutDashboard, Database, HelpCircle } from 'lucide-react';

export default function App() {
  const [view, setView] = React.useState<'upload' | 'dashboard'>('upload');

  const handleStart = (file: File | null) => {
    // Simulating processing
    console.log('Starting processing for:', file?.name);
    setView('dashboard');
  };

  return (
    <div className="min-h-screen flex text-slate-900">
      {/* Sidebar - Optional but adds "Enterprise" feel */}
      <aside className="w-16 md:w-20 bg-slate-900 flex flex-col items-center py-8 gap-8 shrink-0">
        <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
          <Beaker size={20} />
        </div>
        <nav className="flex flex-col gap-6 text-slate-500">
          <NavItem icon={LayoutDashboard} active={view === 'dashboard'} onClick={() => setView('dashboard')} />
          <NavItem icon={Database} />
          <NavItem icon={Settings} />
        </nav>
        <div className="mt-auto">
          <NavItem icon={HelpCircle} />
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto">
        {/* Top Header */}
        <header className="h-16 border-b border-slate-200/60 bg-white/50 backdrop-blur-md sticky top-0 z-20 px-8 flex items-center justify-between">
          <h1 className="font-bold text-slate-800 tracking-tight">智能检测报价系统 <span className="text-slate-300 font-medium px-2">/</span> <span className="text-slate-500 font-medium text-sm">智慧实验室核心 v2.4</span></h1>
          <div className="flex items-center gap-4">
            {view === 'dashboard' && (
              <button 
                onClick={() => setView('upload')}
                className="btn-secondary text-xs"
              >
                返回重新上传
              </button>
            )}
            <div className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white shadow-sm overflow-hidden flex items-center justify-center">
              <span className="text-[10px] font-bold text-slate-500">CX</span>
            </div>
          </div>
        </header>

        <div className="p-8">
          {view === 'upload' ? (
            <UploadSection onStart={handleStart} />
          ) : (
            <div className="max-w-screen-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <StatusDashboard status={mockRunStatus} />
              <div className="space-y-4">
                <div className="flex items-baseline gap-3">
                  <h2 className="text-2xl font-bold tracking-tight text-slate-800">结构化报价报表</h2>
                  <p className="text-slate-400 text-sm font-medium">STRUCTURED QUOTE REPORT</p>
                </div>
                <StructuredReportGrid report={mockReport} />
                <EquipmentTables equipments={mockEquipment} />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon: Icon, active, onClick }: { icon: any, active?: boolean, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`p-3 rounded-xl transition-all ${active ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20 scale-110' : 'hover:bg-slate-800 hover:text-slate-300'}`}
    >
      <Icon size={20} />
    </button>
  );
}
